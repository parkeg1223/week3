#include "RangeArray.h"
#include <iostream>

using namespace std;

RangeArray::RangeArray(int base, int end) : Array(end - base + 1)
{
	low = base;
	high = end;
}

RangeArray::~RangeArray()
{

}

int RangeArray::baseValue()
{
	return low;
}

int RangeArray::endValue()
{
	return high;
}

int& RangeArray::operator[](int i)
{
	static int tmp;
	if (i-low >= 0 && i-low <len)
		return data[i-low];
	else {
		cout << "Array bound error!" << endl;
		return tmp;
	}
}

int RangeArray::operator[](int i) const
{
	return Array::operator[](i-low);
}
